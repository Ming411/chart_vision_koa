// webSocket
const webSocket = require('ws')
const fileUtils = require('../utils/file_utils')
const path = require('path')
// 创建ws服务的对象
const wss = new webSocket.Server({
  port: 9998,
})
// 默认导出一个函数
module.exports.listen = () => {
  wss.on('connection', (client) => {
    console.log('有客户端连接成功了...')
    // 对客户端对象进行message事件监听
    // msg由客户端发送给服务器的数据
    client.on('message', async (msg) => {
      console.log('客户端发送数据给服务器了：' + msg)
      // 由服务器向客户端发送
      let payload = JSON.parse(msg)
      const action = payload.action
      if (action === 'getData') {
        // 拼接文件的绝对路径
        let filePath = '../data/' + payload.chartName + '.json'
        filePath = path.join(__dirname, filePath)
        // 调用封装好的读取文件的工具
        const ret = await fileUtils.getFileJsonData(filePath)
        // 需要在服务端获取到数据的基础上，增加一个data的字段
        payload.data = ret
        // 将数据返回
        client.send(JSON.stringify(payload))
      } else {
        // 原封不动将所接收到的数据转发给每个处于连接装态的客户端
        // wss.clients // 所有已连接的客户端
        wss.clients.forEach((client) => {
          client.send(msg + '')
        })
      }
      // client.send('hello socket from backend')
    })
  })
}
