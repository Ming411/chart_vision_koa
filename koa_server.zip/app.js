const koa = require('koa')
const app = new koa()
// 中间件
const respDurationMiddleware = require('./middleware/koa_response_duration')
app.use(respDurationMiddleware)
const respHeaderMiddleware = require('./middleware/koa_response_header')
app.use(respHeaderMiddleware)
const respDataMiddleware = require('./middleware/koa_response_data')
app.use(respDataMiddleware)
app.listen(8888)

const webSocketService = require('./service/web_socket_services')
// 开启服务端的监听
webSocketService.listen()
