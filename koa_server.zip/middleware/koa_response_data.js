// 处理业务逻辑的中间件，读取某个JSON文件数据
const path = require('path')
const fileUtils = require('../utils/file_utils')
module.exports = async (ctx, next) => {
  const url = ctx.request.url // /api/seller
  let filePath = url.replace('/api', '') // /seller
  filePath = '../data' + filePath + '.json' //  ../data/seller.json
  filePath = path.join(__dirname, filePath)
  try {
    const ret = await fileUtils.getFileJsonData(filePath)
    ctx.response.body = ret
  } catch (error) {
    const errorMsg = {
      message: '读取文件失败，资源不存在',
      status: 404,
    }
    ctx.response.body = JSON.stringify(errorMsg)
  }

  await next()
}
